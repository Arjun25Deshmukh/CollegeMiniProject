package com.cjc.app.main.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class BaseResponse<T> 
{
	private Integer statusCode;
	private String massage;
	private T responseData;

}
