package com.cjc.app.main.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cjc.app.main.entity.User;
import com.cjc.app.main.exeption.UserNotPresent;
import com.cjc.app.main.repository.UserRepository;

@Service
public class UserServiceImpl implements UserService{

	@Autowired
	UserRepository userRepository;
	@Override
	public User saveUser(User user) {
		
		return userRepository.save(user);
	}
	@Override
	public Optional<User> GetAuthUser(String userName, String userCode) {
		
				Optional<User> user  = userRepository.findByUserNameAndUserCode(userName,userCode );
	
				if(user.isPresent())
				{
					return user;
				}
				else {
					throw new UserNotPresent("User Name="+userName);
				}
	
	}

}
