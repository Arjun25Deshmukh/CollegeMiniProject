package com.cjc.app.main.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cjc.app.main.entity.User;
import com.cjc.app.main.exeption.UserNotPresent;
import com.cjc.app.main.repository.UserRepository;

import net.bytebuddy.dynamic.loading.PackageDefinitionStrategy.ManifestReading.SealBaseLocator.ForTypeResourceUrl;
@Service
public class UserServiseImplForCollage  implements UserServiceForCollage{

	@Autowired
	UserRepository ur;

	@Override
	public Optional<User> getUser(String userName) {
	
		Optional<User> user = ur.findByUserName(userName);
		if(user.isPresent())
		{
			return user;
		}
		else {
			throw new UserNotPresent("user name ="+userName);
		}
				
	}
}
