package com.cjc.app.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CollageMinyProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(CollageMinyProjectApplication.class, args);
	}

}
