package com.cjc.app.main.service;

import java.util.Optional;

import com.cjc.app.main.entity.User;

public interface UserService {

public	User saveUser(User user);

public Optional<User> GetAuthUser(String userName, String userCode);

}
