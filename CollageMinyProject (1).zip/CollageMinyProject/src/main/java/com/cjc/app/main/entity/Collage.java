package com.cjc.app.main.entity;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class Collage {
        @Id
        @GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer collageIdentifier;
	private String collageName;
	private String collageCode;
	@OneToOne(cascade = CascadeType.ALL)
	private Address collageLocation;

}
