package com.cjc.app.main.exeption;

public class UserNotPresent extends RuntimeException
{
	public UserNotPresent(String message)
	{
		super(message);
	}

}
