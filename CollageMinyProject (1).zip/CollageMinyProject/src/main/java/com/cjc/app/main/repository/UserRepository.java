package com.cjc.app.main.repository;

import java.util.Optional;

import org.springframework.data.repository.CrudRepository;

import com.cjc.app.main.entity.User;

public interface UserRepository extends CrudRepository<User, Integer>{

public	Optional<User> findByUserNameAndUserCode(String userName, String userCode);

public Optional<User> findByUserName(String userName);

}
