package com.cjc.app.main.controller;

import java.nio.file.attribute.UserPrincipalNotFoundException;
import java.util.Date;
import java.util.Optional;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cjc.app.main.entity.User;
import com.cjc.app.main.exeption.UserNotPresent;
import com.cjc.app.main.response.ApiErroResponse;
import com.cjc.app.main.response.BaseResponse;
import com.cjc.app.main.service.UserService;
import com.fasterxml.jackson.databind.deser.Deserializers.Base;
@CrossOrigin("http://localhost:4200")
@RestController
public class UserController 
{
	@Autowired
	UserService userService;
     @PostMapping("/user")
     public ResponseEntity<BaseResponse<User>> createUser(@RequestBody User user)
     {
    	 Random randomStudent=new Random(9999);
    	 Random randomsCollage=new Random(9999);
    	 user.setUserCode("USER-"+randomStudent.nextInt());
    	 user.getCollage().setCollageCode("CLG-"+randomsCollage.nextInt());
    	
    	 BaseResponse<User> baseResponse=new BaseResponse<User>(201, "User Stored !", userService.saveUser(user));
    	 
    	 
    	 return new ResponseEntity<BaseResponse<User>>(baseResponse,HttpStatus.CREATED);
     }
     
     @GetMapping("/user/{userName}/{userCode}")
     public ResponseEntity<BaseResponse<Optional<User>>> loginAuth
                 (@PathVariable String userName, @PathVariable String userCode)
     {
    	Optional<User> user= userService.GetAuthUser(userName,userCode);

    	
    	BaseResponse<Optional<User>> baseResponse=new BaseResponse<Optional<User>>
    	  (200, "Featchnig Users !",user );
    	
    	 return new ResponseEntity<BaseResponse<Optional<User>>>(baseResponse,HttpStatus.OK);
    
    	
     }

	   @ExceptionHandler(value=UserNotPresent.class)
	     public ResponseEntity<ApiErroResponse> handelUserNotPresent()
	     {  
	    	 ApiErroResponse apiErroResponse=new ApiErroResponse(404,"user Not Present !", new Date());
	    	 return new ResponseEntity<ApiErroResponse>(apiErroResponse,HttpStatus.NOT_FOUND);
	     }
  
     

     
    
}
