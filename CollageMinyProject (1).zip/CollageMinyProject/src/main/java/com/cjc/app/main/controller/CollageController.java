package com.cjc.app.main.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.cjc.app.main.entity.User;
import com.cjc.app.main.response.BaseResponse;
import com.cjc.app.main.service.UserServiceForCollage;

@RestController
public class CollageController {
	
	@Autowired
	UserServiceForCollage usfc;
	
	@GetMapping("/GetSingleUser/{userName}")
	public ResponseEntity<BaseResponse<Optional<User>>> getSingleUser(@PathVariable String userName)
	{
		Optional<User> user=usfc.getUser(userName);
		BaseResponse<Optional<User>> baseResponse =new BaseResponse<Optional<User>>(200, "Fatching User !", user);
		return  new ResponseEntity<BaseResponse<Optional<User>>>(baseResponse,HttpStatus.OK); 
	}

}
