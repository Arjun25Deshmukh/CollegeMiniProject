package com.cjc.app.main.service;

import java.util.Optional;

import com.cjc.app.main.entity.User;

public interface UserServiceForCollage {

	public	Optional<User> getUser(String userName);

}
