package com.cjc.app.main.restExeption;

import java.util.Date;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.cjc.app.main.exeption.UserNotPresent;
import com.cjc.app.main.response.ApiErroResponse;

@RestControllerAdvice
public class ErrorHander {
	
	   @ExceptionHandler(value=UserNotPresent.class)
	     public ResponseEntity<ApiErroResponse> handelUserNotPresent()
	     {  
	    	 ApiErroResponse apiErroResponse=new ApiErroResponse(404,"user Not Present !", new Date());
	    	 return new ResponseEntity<ApiErroResponse>(apiErroResponse,HttpStatus.NOT_FOUND);
	     }

}
